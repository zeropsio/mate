/**
 * The provider runtime SPI — the declared contract between the ported
 * driver zone (`apps/server/src/provider/**`, `./provider*.ts` in this
 * package) and everything owned that consumes provider events
 * (`apps/server/src/spi/**` and, through it, the Zerops feeds).
 *
 * This module re-exports the event union rather than moving or renaming it:
 * `./providerRuntime.ts` stays upstream's file, edited on every port; this
 * file is the one owned place that names a version for what that union
 * currently guarantees, plus the owned enrichment `apps/server/src/spi/`
 * adds on top of it.
 *
 * SPI changelog:
 * - 2.0 (2026-08-29, SPI-1): declared. Surface = `ProviderRuntimeEventV2`
 *   (49 `type`-discriminated members) + the `streamEvents` port. No typed
 *   `toolCall` view yet (SPI-4); no versioned adapter gate reads this
 *   constant yet — it exists so a later slice has one to check against.
 * - 2.1 (2026-08-29, SPI-4): every `SpiEvent` the bus emits now carries an
 *   optional `toolCall: SpiToolCall`, populated on `item.started` /
 *   `item.updated` / `item.completed` when the driver's `payload.data`
 *   shape is recognized (`apps/server/src/spi/toolCall.ts`) — ANY tool, not
 *   only a `zerops_*` one. A tool-lifecycle item
 *   (`isToolLifecycleItemType(payload.itemType)`) whose shape is NOT
 *   recognized never resolves to a silent `undefined`: the bus also exposes
 *   `enrichmentFailures: Stream<SpiEnrichmentFailure>` and logs a warning,
 *   once per (provider, itemType, reason) signature
 *   (`apps/server/src/spi/ProviderRuntimeEventBus.ts`). Owned code under
 *   `apps/server/src/zerops/**` reads `event.toolCall` only — it never reads
 *   `payload.data` again.
 * - (no version bump, 2026-08-29, SPI-5): `apps/server/src/spi/driverHomes.ts`,
 *   `driverLaunch.ts`, `acpSupport.ts`, `openCodeRuntime.ts`, and
 *   `claudeProvider.ts` add small owned, typed capabilities (each with a
 *   contract test) wrapping the driver-internal filesystem/home-dir,
 *   launch-arg, ACP session, and model/effort surfaces `textGeneration/**`
 *   and `usage/**` previously imported from `provider/**` directly. Additive
 *   server-side wrapping only — `ProviderRuntimeEventV2` is unchanged.
 * - 2.2 (2026-09-04, S8b): `SpiToolCall.result` gains an optional `images`
 *   array (`apps/server/src/spi/toolCall.ts`'s `readContentText`-adjacent
 *   image reader), read from an MCP result's image content blocks — the
 *   `zerops_browser` screenshot is the first consumer. Two shapes are read:
 *   Claude's own (live-measured 2026-09-04, mirrors Anthropic's
 *   `ImageBlockParam`) nests `{data, media_type}` under `source`; a flat
 *   `{data, mimeType}` (the raw MCP protocol's own `ImageContent` shape) is
 *   the fallback for Codex, unmeasured. One image over 1 MiB of base64 is
 *   dropped rather than truncated (`imagesDropped: true` records that it
 *   happened — raised from an initial 256 KB once a real screenshot measured
 *   ~301 KB); the existing 48 KB `resultText` cap is unaffected — the two
 *   caps are independent. Additive: a reader that does not know about
 *   `images` still gets `text` exactly as before.
 * - 2.3 (2026-09-05, intake `c8f77e0d4`): `account.rate-limits.updated`'s payload
 *   is `{ limits: ProviderUsageLimitsUpdate }` (upstream `19d8ab2ae`), replacing
 *   `{ rateLimits: unknown }` — a renamed, now typed field. The driver snapshot's
 *   `usageLimits` is the primary carrier (Codex `account/rateLimits/read`, Claude
 *   `get_usage`); the event is an incremental update on top, and no owned reader
 *   existed. `thread.state.changed` gains optional `beforeTokens`/`afterTokens`
 *   (context compaction, `c5ba51d62`), additive.
 * - 2.4 (2026-09-26): `account.rate-limits.updated` gains an optional typed
 *   `blocked: ProviderUsageLimitBlock` (`{ window, resetsAt }`) — the window
 *   that now refuses new requests and when it reopens, emitted whether or not
 *   a turn runs, with `limits.windows` possibly empty. The orchestration usage
 *   pause (`orchestration/Layers/ThreadUsagePauseReactor.ts`) is its first
 *   reader; Claude emits it, the other drivers do not yet. Additive.
 * - 2.5 (2026-09-27): `turn.completed` gains an optional `terminalReason` —
 *   why the driver's agent loop ended (Claude's `terminal_reason`:
 *   `completed`, `prompt_too_long`, `rapid_refill_breaker`, `budget_exhausted`,
 *   `aborted_tools`, ...), passed through as the driver's own word so a
 *   driver that adds one never becomes a decode failure. Until now the
 *   reason reached owned code only as `errorMessage` prose. Added for the
 *   crew engine to tell how a crew turn ended; no owned code reads it yet.
 *   Claude emits it, the other drivers do not yet. Additive.
 * - 2.6 (2026-10-03): an item's lifecycle payload gains an optional
 *   `responseId` — the model response a call was written in, on the start of
 *   each of the agent's own calls (never a helper's) — and an optional
 *   `unreturned` on the completion a turn's end gives a call that never
 *   returned, its `status` kept for older readers. The live run card and the
 *   menu row's live step read a batch as one model response by it, and close
 *   an unreturned call as "No result". Claude emits both, the other drivers
 *   do not; a driver that names no response keeps the order of starts and
 *   returns. Additive.
 * - 2.7 (2026-10-07): an item's lifecycle payload gains an optional
 *   `presentation` — how a call presents itself where its tool name says
 *   too little: an MCP tool's own title and the server it comes from, by
 *   name and icon (`mcpToolPresentation`, `@t3tools/shared/toolActivity`).
 *   Claude emits it from Claude Code's `tool_use_meta`, in an update once
 *   its assistant frame names the call and on every step after; the other
 *   drivers do not yet. Additive.
 * - 2.8 (2026-10-07): an item's `status` gains `stopped` — the call was
 *   cancelled before it ran to an answer (Claude's `tool_result_meta`
 *   `non_execution_kind: "cancelled"`), told apart from a call that failed
 *   or that the person declined. Claude emits it, the other drivers do not
 *   yet. Additive.
 *
 * - 2.9 (2026-10-08): `account.rate-limits.updated` gains optional `refused`:
 *   a parked turn's provider refusal (`true`) or explicit window recovery (`false`),
 *   independent of any reset time. Claude emits it; the other adapters keep their
 *   terminal usage-limit errors. Codex also supplies the existing typed `blocked`
 *   reset on a refused turn when its snapshot names an exhausted window.
 * - 2.10 (2026-10-08): `turn.usage.completed` records own completed native turn
 *   identity, model lines and separately reported turn cost. Claude uses cumulative
 *   final-result ledgers minus a live native baseline, including Task/sidechains.
 *   Codex aggregates exact upstream response meters until the native turn completes.
 *   Zero meters emit nothing; historical models never stand in as participants.
 *   Invalid values remain unknown locally and never disable future facts. Native USD
 *   floats round to decimal nanodollars; pricing basis changes preserve cumulative deltas.
 *   The Claude replay goldens change from individual-response to final-turn facts;
 *   the fresh live baseline replies are constructed, not captured provider evidence.
 *
 * @module providerRuntimeSpi
 */
import type { EventId } from "./baseSchemas.ts";
import type { ProviderDriverKind } from "./providerInstance.ts";
import type { CanonicalItemType, ProviderRuntimeEvent } from "./providerRuntime.ts";

/**
 * The current SPI version. Bump this — and add a changelog entry above —
 * whenever a change to `ProviderRuntimeEventV2` (or the owned `toolCall`
 * enrichment) changes what owned code may depend on (a new member, a
 * renamed field, a narrowed payload shape).
 */
export const PROVIDER_RUNTIME_SPI_VERSION = "2.10";

/**
 * One image content block an MCP tool result carried, e.g. a
 * `zerops_browser` screenshot. `data` is base64, capped at 1 MiB — a larger
 * image is dropped, never truncated (see {@link SpiToolCall.result}'s
 * `imagesDropped`). `width`/`height` are the block's own device-pixel
 * dimensions when the tool reported them; Claude's own image blocks never
 * do (live-measured 2026-09-04) — usually absent in practice.
 */
export interface SpiToolCallImage {
  readonly mimeType: string;
  readonly data: string;
  readonly width?: number;
  readonly height?: number;
}

/**
 * The generic view of one tool call an item lifecycle payload's
 * driver-specific `data` describes — ANY tool, not only a `zerops_*` one.
 *
 * `name` has the `mcp__<server>__` prefix stripped when the driver reports
 * one that way (Claude embeds it in the wire name); `server` is that
 * prefix's middle segment, or the driver's separate server field (Codex),
 * when the call went through MCP — absent for a driver-native tool (Claude's
 * Bash, a subagent Task, ...). `result` is present once the call has
 * returned; absent on `item.started` and on an `item.updated` still in
 * flight.
 */
export interface SpiToolCall {
  readonly name: string;
  readonly rawName: string;
  readonly server?: string;
  readonly arguments?: unknown;
  readonly result?: {
    readonly text: string;
    readonly failed: boolean;
    /** Image content blocks the result carried, each under the 1 MiB cap. Absent when none did. */
    readonly images?: ReadonlyArray<SpiToolCallImage>;
    /** `true` when at least one image content block was dropped for exceeding the cap. */
    readonly imagesDropped?: boolean;
  };
}

/**
 * The event type owned code depends on. `toolCall` is owned enrichment
 * (`apps/server/src/spi/toolCall.ts`) layered on top of what the driver
 * itself emits — populated by the bus, never decoded from `payload.data` by
 * anything outside that one file.
 */
export type SpiEvent = ProviderRuntimeEvent & { readonly toolCall?: SpiToolCall };

/**
 * Reported on the bus's `enrichmentFailures` side channel (and logged, once
 * per (provider, itemType, reason) signature) when an item the driver marked
 * as a tool (`isToolLifecycleItemType(payload.itemType)`) carries a `data`
 * shape `apps/server/src/spi/toolCall.ts` does not recognize — the signal
 * that a ported driver changed a tool-call shape and stopped reaching
 * `event.toolCall`, instead of that happening silently.
 */
export interface SpiEnrichmentFailure {
  readonly eventId: EventId;
  readonly provider: ProviderDriverKind;
  readonly itemType: CanonicalItemType;
  readonly reason: string;
}
