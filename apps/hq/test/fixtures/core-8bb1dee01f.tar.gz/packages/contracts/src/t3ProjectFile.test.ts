import * as Schema from "effect/Schema";
import { describe, expect, it } from "vite-plus/test";

import { T3ProjectFile } from "./t3ProjectFile.ts";

const decode = Schema.decodeUnknownSync(T3ProjectFile);

describe("T3ProjectFile", () => {
  it("decodes a full project file", () => {
    const decoded = decode({
      $schema: "https://t3.codes/schema/t3.json",
      iconPath: "assets/logo.svg",
      scripts: [
        {
          name: "Dev",
          command: "pnpm dev",
          icon: "play",
          runOnWorktreeCreate: false,
        },
        { name: "Test", command: "pnpm test" },
      ],
    });

    expect(decoded.iconPath).toBe("assets/logo.svg");
    expect(decoded.scripts).toHaveLength(2);
    expect(decoded.scripts?.[1]).toEqual({ name: "Test", command: "pnpm test" });
  });

  it("decodes an empty object and ignores unknown fields", () => {
    expect(decode({})).toEqual({});
    expect(decode({ futureField: true })).toEqual({});
  });

  it("trims icon paths and script fields", () => {
    const decoded = decode({
      iconPath: " assets/logo.svg ",
      scripts: [{ name: " Dev ", command: " pnpm dev " }],
    });

    expect(decoded.iconPath).toBe("assets/logo.svg");
    expect(decoded.scripts?.[0]).toEqual({ name: "Dev", command: "pnpm dev" });
  });

  it("project file decodes a script carrying previewUrl and autoOpenPreview", () => {
    const decoded = decode({
      scripts: [
        {
          name: "Dev",
          command: "pnpm dev",
          previewUrl: "http://localhost:3000",
          autoOpenPreview: true,
        },
      ],
    });

    expect(decoded.scripts?.[0]).toEqual({ name: "Dev", command: "pnpm dev" });
    expect(decoded.scripts?.[0]).not.toHaveProperty("previewUrl");
    expect(decoded.scripts?.[0]).not.toHaveProperty("autoOpenPreview");
  });

  it("rejects scripts without a command", () => {
    expect(() => decode({ scripts: [{ name: "Dev" }] })).toThrow();
  });

  it("rejects unknown script icons", () => {
    expect(() =>
      decode({ scripts: [{ name: "Dev", command: "pnpm dev", icon: "rocket" }] }),
    ).toThrow();
  });

  it("decodes defaultThreadEnvMode and rejects unknown modes", () => {
    expect(decode({ defaultThreadEnvMode: "worktree" }).defaultThreadEnvMode).toBe("worktree");
    expect(decode({ defaultThreadEnvMode: "local" }).defaultThreadEnvMode).toBe("local");
    expect(() => decode({ defaultThreadEnvMode: "remote" })).toThrow();
  });

  it("decodes worktreeSubmodules and rejects unknown modes", () => {
    expect(decode({ worktreeSubmodules: "none" }).worktreeSubmodules).toBe("none");
    expect(decode({ worktreeSubmodules: "top-level" }).worktreeSubmodules).toBe("top-level");
    expect(() => decode({ worktreeSubmodules: "shallow" })).toThrow();
  });
});
