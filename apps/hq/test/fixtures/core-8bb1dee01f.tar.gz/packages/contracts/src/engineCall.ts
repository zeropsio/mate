/**
 * What an engine call's record says besides its step, tool and words: the line it was given, what
 * its row shows, its Zerops result and the parts of it read on demand — what a V1 call's activity
 * payload carries, so a call reads the same on either engine.
 *
 * @module engineCall
 */
import * as Schema from "effect/Schema";

import { ImageOccurrence, PageOccurrence } from "./assetReference.ts";

/** The longest input line a call's record keeps, in UTF-16 code units (V1's activity detail). */
export const CALL_INPUT_MAX = 180;

/**
 * A picture a Zerops result carried, as a reference to the Mate's content-addressed asset store
 * (rule 8: pictures travel as references, never bytes): its occurrence, as V1's capture stores it
 * (`assets/ConversationMedia.ts`), and its size.
 */
export const CallResultPicture = Schema.Struct({
  mimeType: Schema.String,
  asset: ImageOccurrence,
  width: Schema.optionalKey(Schema.Number),
  height: Schema.optionalKey(Schema.Number),
});
export type CallResultPicture = typeof CallResultPicture.Type;

/** The largest page a call records: zcp's own cap on a published page (`ops.PageMaxBytes`). */
export const PAGE_MAX_BYTES = 8 * 1024 * 1024;

/** The tallest a page stands in a conversation, in CSS pixels; a taller one scrolls inside. */
export const PAGE_MAX_HEIGHT = 4000;
/** The widest and narrowest a page's frame is measured at, in CSS pixels. */
export const PAGE_WIDTH_MIN = 200;
export const PAGE_WIDTH_MAX = 4000;
/** How many widths a page's heights are kept for: the newest. */
export const PAGE_HEIGHTS_KEPT = 12;

/** A page's height as a client laid it out: `[width, height]`, in CSS pixels. */
export const PageHeight = Schema.Tuple([Schema.Int, Schema.Int]);
export type PageHeight = typeof PageHeight.Type;

/**
 * A page the agent published (`zerops_publish_page`) for the person to see above its reply: a
 * self-contained HTML document kept in the Mate's asset store, by reference as a picture is, with
 * its title, its size in bytes and when the call that published it ended.
 */
export const CallResultPage = Schema.Struct({
  asset: PageOccurrence,
  title: Schema.String,
  bytes: Schema.Number,
  publishedAt: Schema.Number,
  /**
   * The page's height at each width a client laid it out at (`engine.recordPageHeight`), by
   * width: a later view paints at the nearest one's from its first frame.
   */
  heights: Schema.optionalKey(Schema.Array(PageHeight)),
});
export type CallResultPage = typeof CallResultPage.Type;

/**
 * A `zerops_*` call's result, as V1's activity carries it (`ZeropsActivityResult`): the tool's
 * name, its text verbatim — absent while it runs, or when it was over the server's limit
 * (`truncated`) — and its pictures by reference. The client decodes the text into its card.
 */
export const CallResult = Schema.Struct({
  toolName: Schema.String,
  resultText: Schema.optionalKey(Schema.String),
  truncated: Schema.optionalKey(Schema.Boolean),
  images: Schema.optionalKey(Schema.Array(CallResultPicture)),
  imagesDropped: Schema.optionalKey(Schema.Boolean),
  /** The page it published, on the engine only. */
  page: Schema.optionalKey(CallResultPage),
});
export type CallResult = typeof CallResult.Type;

/**
 * A call's whole parts, read on demand by name (`engine.readDetail`): its output as the driver
 * streamed it (`detail`), its own record as the driver gave it (`data`), a result cut to the
 * wire's budget (`result`). A newer build's part decodes as its name.
 */
export const CALL_PARTS = ["detail", "data", "result"] as const;

export const callFields = {
  /** What the call was given, as one line: the command, the path, the query. */
  input: Schema.optionalKey(Schema.String),
  /**
   * What its row shows besides its line, in the terms every client's run card reads a call by
   * (V1's projected activity data): the tool's name, the command, the input's named fields, the
   * files it changed, the picture it looked at, whether it wrote, the first line of its output.
   * Bounded by the server; its open keys are for the card, never for a rule.
   */
  shows: Schema.optionalKey(Schema.Record(Schema.String, Schema.Unknown)),
  /** A `zerops_*` call's result. */
  result: Schema.optionalKey(CallResult),
  /** The parts of it that can be read whole on demand. */
  parts: Schema.optionalKey(Schema.Array(Schema.String)),
} as const;

// ── steps ───────────────────────────────────────────────────────────────────────────────────

/** A call's step by the kind of item its driver made it: one step per kind, read back exactly. */
const KIND_STEPS: Readonly<Record<string, string>> = {
  command_execution: "command",
  file_change: "edit",
  web_search: "web",
  image_view: "look",
  collab_agent_tool_call: "helper",
  mcp_tool_call: "mcp",
  dynamic_tool_call: "tool",
};

/** The kind of item each step reads back as on a client: the inverse of `callStep`. */
export const STEP_ITEM_KINDS: Readonly<Record<string, string>> = {
  command: "command_execution",
  edit: "file_change",
  web: "web_search",
  look: "image_view",
  helper: "collab_agent_tool_call",
  mcp: "mcp_tool_call",
  tool: "dynamic_tool_call",
  read: "dynamic_tool_call",
  search: "dynamic_tool_call",
};

/** The tools a generic call reads a file or searches code with, as every driver names them. */
const NAMED_STEPS: Readonly<Record<string, string>> = {
  read: "read",
  "read file": "read",
  grep: "search",
  glob: "search",
  search: "search",
  codesearch: "search",
  list: "search",
  ls: "search",
};

/**
 * The step a call takes: its item's kind, and for a generic call what it did where its tool says
 * so — a file read, a code search — as V1's effort counts it (Claude's `Read: {…}` line, an
 * OpenCode or ACP tool's name or kind, a call titled "Read File").
 */
export function callStep(
  kind: string,
  facts: { readonly line?: string; readonly shows?: Readonly<Record<string, unknown>> },
  title: string | undefined,
): string {
  const step = KIND_STEPS[kind] ?? "tool";
  if (kind !== "dynamic_tool_call") return step;
  const named = /^([A-Za-z][\w-]*):\s*[{[]/.exec(facts.line ?? "")?.[1];
  const toolName = facts.shows?.toolName;
  const own =
    named ??
    (typeof toolName === "string" && !toolName.startsWith("mcp__") ? toolName : undefined) ??
    (typeof facts.shows?.kind === "string" ? facts.shows.kind : undefined) ??
    title;
  return (own === undefined ? undefined : NAMED_STEPS[own.trim().toLowerCase()]) ?? step;
}

// ── a V1 call brought over ──────────────────────────────────────────────────────────────────

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);

const isPicture = Schema.is(CallResultPicture);

/** A V1 result as a record holds it: inline pictures out (`imagesDropped`), references kept. */
const resultOf = (zerops: Record<string, unknown>): CallResult | undefined => {
  if (typeof zerops.toolName !== "string" || zerops.toolName.length === 0) return undefined;
  const given = Array.isArray(zerops.images) ? zerops.images : [];
  const images = given.filter(isPicture);
  return {
    toolName: zerops.toolName,
    ...(typeof zerops.resultText === "string" ? { resultText: zerops.resultText } : {}),
    ...(zerops.truncated === true ? { truncated: true } : {}),
    ...(images.length === 0 ? {} : { images }),
    ...(zerops.imagesDropped === true || images.length < given.length
      ? { imagesDropped: true }
      : {}),
  };
};

/**
 * A call V1 recorded, as an engine call's record carries it: its item data from the history
 * import (`{source: "v1", kind, summary, payload}`, `payload` V1's client-projected tool payload)
 * read into the step, input line, facts and result a live call's record carries, so an imported
 * call draws as a live one. Anything else gives nothing.
 */
export function importedCallFields(data: unknown): {
  readonly step?: string;
  readonly input?: string;
  readonly shows?: Readonly<Record<string, unknown>>;
  readonly result?: CallResult;
} {
  if (!isRecord(data) || data.source !== "v1" || !isRecord(data.payload)) return {};
  const payload = data.payload;
  const itemType = typeof payload.itemType === "string" ? payload.itemType : "dynamic_tool_call";
  const { zerops, toolCallId: _native, ...shown } = isRecord(payload.data) ? payload.data : {};
  const shows = Object.keys(shown).length === 0 ? undefined : shown;
  const input =
    typeof payload.detail === "string" && payload.detail.length > 0
      ? payload.detail.length > CALL_INPUT_MAX
        ? `${payload.detail.slice(0, CALL_INPUT_MAX - 3)}...`
        : payload.detail
      : undefined;
  const result = isRecord(zerops) ? resultOf(zerops) : undefined;
  const title =
    typeof payload.title === "string"
      ? payload.title
      : typeof data.summary === "string"
        ? data.summary
        : undefined;
  return {
    step: callStep(
      itemType,
      {
        ...(input === undefined ? {} : { line: input }),
        ...(shows === undefined ? {} : { shows }),
      },
      title,
    ),
    ...(input === undefined ? {} : { input }),
    ...(shows === undefined ? {} : { shows }),
    ...(result === undefined ? {} : { result }),
  };
}
